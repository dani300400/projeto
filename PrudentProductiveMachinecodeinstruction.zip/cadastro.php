<?php
// Conexão com o banco de dados (ajuste as configurações conforme seu ambiente)
$host = "localhost";
$user = "seu_usuario";
$pass = "sua_senha";
$dbname = "seu_banco_de_dados";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

// Recebe os dados do formulário
$login = $_POST["login"];
$senha = md5($_POST["senha"]); // Criptografa a senha (use hash mais seguro em produção)

// Insere os dados na tabela
$sql = "INSERT INTO usuarios (login, senha) VALUES ('$login', '$senha')";

if ($conn->query($sql) === TRUE) {
    echo "Cadastro realizado com sucesso!";
} else {
    echo "Erro ao cadastrar: " . $conn->error;
}

$conn->close();
?>
